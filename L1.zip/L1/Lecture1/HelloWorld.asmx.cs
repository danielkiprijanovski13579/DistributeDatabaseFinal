﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;

namespace Lecture1
{
    /// <summary>
    /// Summary description for HelloWorld
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
    // [System.Web.Script.Services.ScriptService]
    public class HelloWorld : System.Web.Services.WebService
    {

        [WebMethod]
        public string HelloWorld1()
        {
            return "Hello World";
        }

        [WebMethod]
        public string WhoIAm()
        {
            return "First Name and ID";
        }

        [WebMethod]
        public string CurrentTime()
        {
            //return DateTime.Now.ToString("T");
            return DateTime.Now.ToString("HH:mm:ss");
        }

        [WebMethod]
        public string CurrentDate()
        {
            //return DateTime.Now.ToString("D");
            return DateTime.Now.ToString("dd.MM.yyyy");
        }

        [WebMethod]
        public string CurrentDateAndTime()
        {
            return DateTime.Now.ToString("T") + " " + DateTime.Now.ToString("D");
        }

        [WebMethod]
        public string EnteredWord(String name)
        {
            return name;
        }

        [WebMethod]
        public string Sum(int a, int b)
        {
            return (a+b).ToString();
        }

        [WebMethod]
        public int Rnd()
        {
            Random R = new Random();
            int num = R.Next();
            return num;
        }


        [WebMethod]
        public int Rnd_up_to(int max)
        {
            Random R = new Random();
            int num = R.Next(max);
            return num;
        }

        [WebMethod]
        public int Rnd_from_to(int min, int max)
        {
            Random R = new Random();
            int num = R.Next(min, max);
            return num;
        }
        [WebMethod]
        public float C_to_F(int c)
        {
            float F = c * 9 / 5 + 32;
            return F;
        }

        [WebMethod]
        public double E_to_D(double eu)
        {
            double den = eu * 61.5;
            return den;
        }

        [WebMethod]
        public double cm_to_inch(int cm)
        {
            double inch = cm / 2.54;
            return inch;
        }

        public double State_tax(int gross)
        {
            return gross * 28.4 / 100;
        }

        [WebMethod]
        public double NET(int gross)
        {

            double ST = State_tax(gross);
            double PT = (gross - ST - 7470) * 10 / 100;
            if (PT < 0)
                PT = 0;
            double NET = gross - ST - PT;
            return NET;

        }

        [WebMethod]
        public string NET_detals(int gross)
        {
            double ST = State_tax(gross);
            double PT = (gross - ST - 7470) * 10 / 100;
            if (PT < 0)
                PT = 0;
            double NET = gross - ST - PT;
            return "Gross: " + gross + " State tax:" + ST + "Personal tax:" + PT + " NET:" + NET;

        }
    }
}
